<?php

function cache($ttl, $key, $func) {
  $path = __DIR__ . DIRECTORY_SEPARATOR . 'tmp' . DIRECTORY_SEPARATOR . $key;
  
  if (file_exists($path) && is_readable($path)) {
    $content = file_get_contents($path);
    $content = json_decode($content, true);
    
    if (time() < $content['etime']) {
      return $content['val'];
    }
  }

  $val = $func();
  file_put_contents($path, json_encode(['etime' => time() + $ttl, 'val' => $val]));
  return $val;
}

$str = cache(10, 'a', function() {
  // 十秒鐘內 都不會跑這裡面的東西
  return time();
});

echo $str;